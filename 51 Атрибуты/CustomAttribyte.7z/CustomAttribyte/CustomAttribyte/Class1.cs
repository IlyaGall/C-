﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomAttribyte
{
   

    [CustomAttribyte("Mike", "2020-10-02", 11576)]
    public class Class1
    {

    }
}
