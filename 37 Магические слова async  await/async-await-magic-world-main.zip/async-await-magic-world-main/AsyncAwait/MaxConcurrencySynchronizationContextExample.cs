﻿namespace AsyncAwait
{
    internal class MaxConcurrencySynchronizationContextExample
    {
        internal async Task ShowExample()
        {
            // Create context that allows only 2 concurrent operations
            using var context = new MaxConcurrencySynchronizationContext(maxConcurrentTasks: 2);
            SynchronizationContext.SetSynchronizationContext(context);

            // Example 1: Processing a collection of items
            var urls = new[]
            {
            "https://api.example.com/1",
            "https://api.example.com/2",
            "https://api.example.com/3",
            "https://api.example.com/4",
            "https://api.example.com/5"
        };

            Console.WriteLine("Starting API calls with limited concurrency...");
            using var client = new HttpClient();

            foreach (var url in urls)
            {
                context.Post(async _ =>
                {
                    try
                    {
                        Console.WriteLine($"Starting request to {url}");
                        Console.WriteLine($"Current running tasks: {context.CurrentRunningTasks}");

                        // Simulate API call
                        await Task.Delay(1000);

                        Console.WriteLine($"Completed request to {url}");
                        Console.WriteLine($"After completed request: current running tasks: {context.CurrentRunningTasks}");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error processing {url}: {ex.Message}");
                    }
                }, null);
            }

            // Example 2: Using with async/await pattern
            async Task ProcessItemAsync(int item)
            {
                Console.WriteLine($"Start Processed item {item}");
                Console.WriteLine($"Processed item Current running tasks: {context.CurrentRunningTasks}");
                await Task.Delay(500); // Simulate processing

            }

            var tasks = new List<Task>();
            for (int i = 0; i < 10; i++)
            {
                int itemCopy = i;
                var task = Task.Run(async () =>
                {
                    await ProcessItemAsync(itemCopy);
                });
                tasks.Add(task);
            }

            // Wait for all tasks to complete
            await Task.WhenAll(tasks);

            // Example 3: Using Send for synchronous execution
            context.Send(_ =>
            {
                Console.WriteLine("This executes synchronously and blocks until complete");
                Thread.Sleep(1000);
            }, null);

            Console.WriteLine("All operations completed!");
        }


    }
}
