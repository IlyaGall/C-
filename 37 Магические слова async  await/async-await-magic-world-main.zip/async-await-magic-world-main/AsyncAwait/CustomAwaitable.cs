﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace AsyncAwait
{
    public class CustomAwaitable
    {
        public CustomAwaiter<A> GetAwaiter() => new CustomAwaiter<A>();

        public class CustomAwaiter<TResult>: INotifyCompletion 
        {
            public bool IsCompleted => false; // Simulate asynchronous behavior

            public void OnCompleted(Action continuation)
            {
                // Simulate an asynchronous operation by scheduling the continuation
                Task.Run(() =>
                {
                    Task.Delay(1000).Wait();
                    continuation();
                });
            }

            public TResult GetResult()
            {
                return default(TResult);
            }
        }

        public class A() { }
    }
}
