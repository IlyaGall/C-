﻿var _now = DateTime.Now;

object _lock = new object();
Thread t1 = new Thread(T1);
t1.Start();

Thread.Sleep(50);
Thread t2 = new Thread(T2);
t2.Start();

Thread.Sleep(50);
Thread t3 = new Thread(T3);
t3.Start();


Thread.Sleep(50);
Thread t4 = new Thread(T4);
t4.Start();


void T1()
{
    Log("T1");
    lock (_lock)
    {
        Log("T1 entered");
        Thread.Sleep(1000);
        Log("T1 wait");
        Monitor.Wait(_lock);
        Log("T1 after wait");
    }
    Log("T1 left");
}

void T3()
{
    Log("T3");
    lock (_lock)
    {
        Log("T3 entered");
        Thread.Sleep(1000);
        Log("T3 wait");
        Monitor.Wait(_lock);
        Log("T3 after wait");
    }
    Log("T3 left");
}

void T4()
{
    Log("T4");
    lock (_lock)
    {
        Log("T4 entered");
        Thread.Sleep(1000);
        Log("T4 pulse");
        Monitor.PulseAll(_lock);
        Log("T4 after pulse");
    }
    Log("T4 left");
}


void T2()
{
    Log("T2");
    lock (_lock)
    {
        Log("T2 entered");
        Thread.Sleep(1000);
        Log("T2 pulse");
        Monitor.PulseAll(_lock);
        Log("T2 after pulse");
    }
    Log("T2 left");
}


void Log(string msg)
{
    Console.WriteLine($"{(DateTime.Now - _now).TotalMilliseconds}\t[{Environment.CurrentManagedThreadId}] | {msg}");
}