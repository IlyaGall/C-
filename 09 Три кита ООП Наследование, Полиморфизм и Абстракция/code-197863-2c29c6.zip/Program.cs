﻿using System;
using System.ComponentModel.Design;
using System.IO;
using System.Reflection.Metadata.Ecma335;
using System.Threading;

namespace Otus.Exceptions
{

    class Vehicle
    {
        public string Name;
    }

    class Car : Vehicle
    {
        public Car(string vin)
        {
            Vin = vin;
        }

        public string Vin;
    }


    class WrongTurnException : Exception
    {
        public DateTime TimeStamp;

        public WrongTurnException(string message) : base(message) { }
    }


    class RightTurnException : Exception
    {
        public DateTime TimeStamp;

        public RightTurnException(string message) : base(message) { }
    }

    class SuperException : RightTurnException
    {

        public SuperException(string message) : base(message) { }
    }


    class Program
    {


        static void InnerFunction()
        {
            var a = 0;
            var b = 4;
            var arr = new[] { 1, 2 };

            try
            {

                if (a == 0)
                {
                    //  var ex = new Exception("Something wrong");

                    var ex = new WrongTurnException("aaaa");
                    ex.TimeStamp = DateTime.Now;

                    ex.Data.Add("timestamp", DateTime.Now);
                    ex.Data.Add("b", b);
                    throw ex;
                }
                else
                {
                    Console.WriteLine(b / a);

                }
            }

            //catch(Exception ex)
            //{
            //    if(ex is WrongTurnException)
            //    {

            //    }
            //    else if (ex is RightTurnException)
            //    {

            //    }
            //}

            catch (SuperException fancyException)
            {
                Console.WriteLine($"Something went wrong: when: {fancyException.Data["timestamp"]} when b was = {fancyException.Data["b"]}");
                throw;
            }

            catch (WrongTurnException fancyException)
            {
                Console.WriteLine($"Something went wrong: when: {fancyException.Data["timestamp"]} when b was = {fancyException.Data["b"]}");


                throw;

            }
            catch (RightTurnException fancyException)
            {
                Console.WriteLine($"Something went wrong: when: {fancyException.Data["timestamp"]} when b was = {fancyException.Data["b"]}");
            }


            catch (Exception e)
            {

            }
        }

        static void NotSoDeepFunction()
        {
            InnerFunction();
        }

        static void AnotherOneFunction()
        {
            NotSoDeepFunction();
        }


        class Result
        {
            public Object Data;
            public bool IsOk;
        }


        static Result Divide(int a, int b)
        {
            if (b == 0)
            {
                // throw 
                return new Result { IsOk = false };
            }
            else
            {
                return new Result
                {
                    IsOk = true,
                    Data = a / b
                };
            }
        }


        static void Main(string[] args)
        {
            //try
            //{
            //    AnotherOneFunction();
            //}
            //catch (Exception e)
            //{
            //    Console.WriteLine(e.Message);
            //}


            //try
            //{
            //    var a = 0;
            //    var b = 4;
            //    var c = b / a;
            //}
            //finally
            //{
            //    Console.WriteLine("Finita");
            //}
            //using (var f=new FileStream("f.txt", FileMode.Open))
            //{
            //    f.Write("asfsafa");
            //}

            //FileStream f;

            //try
            //{
            //    f = new FileStream("f.txt", FileMode.Open);
            //    f.Write("afsaf");
            //}
            //finally
            //{
            //    f.Dispose();
            //}






            //Console.WriteLine("AAAAAAAAAAAAA");
            ComplexExceptionDemo.Demo();

            Console.WriteLine("asfafasf");
            var fancyCar = new Car("12345");
            fancyCar.Name = "X-trail";

        }


    }


}
