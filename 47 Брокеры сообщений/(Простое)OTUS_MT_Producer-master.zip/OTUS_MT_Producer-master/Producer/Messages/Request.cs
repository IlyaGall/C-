using CommonNamespace;

namespace CommonNamespace
{
    public class Request
    {
        public MessageDto Message { get; set; }
    }
}