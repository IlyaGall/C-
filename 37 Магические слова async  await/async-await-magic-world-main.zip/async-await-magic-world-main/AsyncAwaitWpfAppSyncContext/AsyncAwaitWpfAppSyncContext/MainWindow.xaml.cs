﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AsyncAwaitWpfAppSyncContext
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        volatile int _counter = 0;

        private async void Button1_Click(object sender, RoutedEventArgs e)
        {
            _counter++;
            var currentContext = System.Threading.SynchronizationContext.Current;
            await Task.Delay(1000).ConfigureAwait(true);       // if true - no deadlock, if false - deadlock
            TextBox1.Text = $"Button Clicked {_counter} times";

            //Dispatcher.Invoke(() => TextBox1.Text = $"Button Clicked {_counter} times");  // Possible to solve deadlock 1 variant

                     
            //currentContext.Post((state) => TextBox1.Text = $"Button Clicked {_counter} times", null);// Possible to solve deadlock 2 variant
        }

        private async void Button2_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Blocking call to an async method
                var r = GetLibraryData();
                //r.Wait(); // This will block the UI thread
                //string result = GetLibraryData().Result; // This blocks the UI thread 
                string result =await  GetLibraryData(); // Сorrect way
                MessageBox.Show(r.Result);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async Task<string> GetLibraryData()
        {
            var library = new Library();
            return await library.GetDataAsync().ConfigureAwait(true);
        }
    }

    public class Library
    {
        public async Task<string> GetDataAsync()
        {
            // Simulating an asynchronous delay
            await Task.Delay(100).ConfigureAwait(false); // Captures the WPF UI synchronization context
            Task.Delay(5000).Wait(); // This will block the UI thread on 5 seconds
            return "Data from library";
        }
    }

}