﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace AsyncAwait
{
    internal class IAsyncEnumerableExample
    {
        public async IAsyncEnumerable<int> GetNumbersAsync([EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            for (int i = 1; i <= 10; i++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                await Task.Delay(500); // Simulate async work
                yield return i;
            }
        }

        public async Task Show()
        {
            using var cts = new CancellationTokenSource();
            cts.CancelAfter(2000); // Cancel after 2 seconds

            try
            {
                await foreach (var number in GetNumbersAsync(cts.Token))
                {
                    Console.WriteLine($"Number: {number}");
                }
            }
            catch (OperationCanceledException)
            {
                Console.WriteLine("Operation was canceled.");
            }
        }
    }
}
