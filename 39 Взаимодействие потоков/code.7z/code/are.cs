﻿var _now = DateTime.Now;

AutoResetEvent autoResetEvent = new AutoResetEvent(true);

Parallel.For(0, 10, DoWork);

// Программа для запоминания 10 слов
void DoWork(int id)
{
    Log($"Поток {id} генерируем звучание слова");
    Thread.Sleep(new Random().Next(500, 1000)); // Генерируем звучание
    autoResetEvent.WaitOne();
    Log($"[{id}] Воспроизводим звук");
    Thread.Sleep(new Random().Next(200, 500)); // Воспроизводим звук
    autoResetEvent.Set();
    Log("set");
}

void Log(string msg)
{
    Console.WriteLine($"{(DateTime.Now - _now).TotalMilliseconds}\t[{Environment.CurrentManagedThreadId}] | {msg}");
}