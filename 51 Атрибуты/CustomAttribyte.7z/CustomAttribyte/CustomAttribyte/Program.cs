﻿/*
 3 примера получения данных из атрибута
string remark;
remark = (typeof(UseAttribute).GetCustomAttribute(typeof(RemarkAttribute)) as RemarkAttribute).Remark;
remark = (typeof(UseAttribute).GetCustomAttributes(typeof(RemarkAttribute)).Single() as RemarkAttribute).Remark;
remark = typeof(UseAttribute).GetCustomAttributesData().Single(x => x.AttributeType == typeof(RemarkAttribute)).ConstructorArguments.First().Value.ToString();


 */

using System.Reflection;

namespace CustomAttribyte
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Class1 class1 = new Class1();
            var collectionAt = typeof(Class1).GetCustomAttributes(typeof(CustomAttribyte)).First() as CustomAttribyte;
            if (collectionAt != null)
            {
                Console.WriteLine($"{collectionAt.Name} {collectionAt.DateTime} {collectionAt.Number} ");
            }
          

        }
    }
}
