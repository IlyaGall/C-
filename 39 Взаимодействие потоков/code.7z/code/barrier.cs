﻿var _now = DateTime.Now;

Barrier bar;
int numberOfWorkers = 10;

bar = new Barrier(numberOfWorkers, AnnounceEndOfPhase);
Parallel.For(0, numberOfWorkers, DoWork);

void DoWork(int id)
{
    Thread.Sleep(new Random().Next(50, 100));
    Log($"[Фаза {bar.CurrentPhaseNumber}] Часть данных №{id} успешно скачана");
    bar.SignalAndWait();
    Thread.Sleep(new Random().Next(50, 100));
    Log($"[Фаза {bar.CurrentPhaseNumber}] Обучение на данных №{id} завершено");
    bar.SignalAndWait();
    Thread.Sleep(new Random().Next(50, 100));
    Log($"[Фаза {bar.CurrentPhaseNumber}] Серия тестов №{id} прошла успешно");
    bar.SignalAndWait();
}

void AnnounceEndOfPhase(Barrier barrier)
{
    switch (barrier.CurrentPhaseNumber)
    {
        case 0:
            Log("Скачивание всех частей завершено. Можно отключать интернет.");
            Log("");
            break;
        case 1:
            Log("Обучение нейронной сети завершено. Подготавливаем тестирующие выборки.");
            Log("");
            break;
        case 2:
            Log("Тестирование завершено успешно. Искусственный интеллект готов к мировому господству! =)");
            Log("");
            break;
    }
}


void Log(string msg)
{
    Console.WriteLine($"{(DateTime.Now - _now).TotalMilliseconds}\t[{Environment.CurrentManagedThreadId}] | {msg}");
}