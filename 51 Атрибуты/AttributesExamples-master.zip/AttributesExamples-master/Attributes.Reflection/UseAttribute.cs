﻿namespace Attributes.Reflection
{
    internal partial class Program
    {
        [RemarkAttribute("This class uses an attribute.")]
        class UseAttribute { }

    }
}
