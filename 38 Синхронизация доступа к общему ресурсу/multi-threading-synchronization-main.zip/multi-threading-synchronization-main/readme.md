# Demo poject for Otus C# Professional course

## Synchronization access to shared resource
