﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncAwait
{
    public class DataFetcher
    {
        private readonly ConcurrentDictionary<int, string> _cache = new();

        public async ValueTask<string> GetDataAsync(int id)
        {
            // Check if the data is already in the cache
            if (_cache.TryGetValue(id, out var cachedValue))
            {
                return cachedValue; // Return cached value synchronously
            }

            // Simulate an asynchronous data fetch
            var data = await FetchFromDatabaseAsync(id);

            // Cache the result for future use
            _cache[id] = data;

            return data;
        }

        private async Task<string> FetchFromDatabaseAsync(int id)
        {
            await Task.Delay(1000); // Simulate delay
            return $"Data for ID {id}";
        }
    }
}
