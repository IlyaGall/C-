﻿using System.ComponentModel.DataAnnotations.Schema;

namespace MyLibrary
{
    [Table("table_persons", Schema = "dbo")]
    public class Persons
    {
        [Column("id", Order = 1, TypeName = "int")]
        public int Id { get; set; }

        [Column("name", Order = 2, TypeName = "varchar(50)")]
        public string Name { get; set; }
        
        [Column("surname", Order = 3, TypeName = "varchar(50)")]
        public string Surname { get; set; }
        public string PhoneNumber { get; set; }
    }
}
