namespace CommonNamespace
{
    public class MessageDto
    {
        public string Content { get; set; }
    }
}