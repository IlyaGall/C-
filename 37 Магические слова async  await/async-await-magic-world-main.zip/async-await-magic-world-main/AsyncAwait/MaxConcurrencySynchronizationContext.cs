﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncAwait
{

        internal sealed class MaxConcurrencySynchronizationContext : SynchronizationContext,IDisposable
    {
        private readonly SemaphoreSlim _semaphore;
        private readonly ConcurrentQueue<(SendOrPostCallback, object)> _queue;
        private readonly int _maxConcurrentTasks;
        private int _runningTasks;
        private readonly CancellationTokenSource _cancellation;

        public MaxConcurrencySynchronizationContext(int maxConcurrentTasks)
        {
            _maxConcurrentTasks = maxConcurrentTasks;
            _semaphore = new SemaphoreSlim(maxConcurrentTasks);
            _queue = new ConcurrentQueue<(SendOrPostCallback, object)>();
            _cancellation = new CancellationTokenSource();

            // Start the background processor
            Task.Run(ProcessQueueAsync);
        }

        public override void Post(SendOrPostCallback callback, object state)
        {
            _queue.Enqueue((callback, state));
        }

        public override void Send(SendOrPostCallback callback, object state)
        {
            var resetEvent = new ManualResetEventSlim(false);
            Exception exception = null;

            Post(wrapper, null);
            resetEvent.Wait();

            if (exception != null)
                throw exception;

            void wrapper(object _)
            {
                try
                {
                    callback(state);
                }
                catch (Exception ex)
                {
                    exception = ex;
                }
                finally
                {
                    resetEvent.Set();
                }
            }
        }

        private async Task ProcessQueueAsync()
        {
            while (!_cancellation.Token.IsCancellationRequested)
            {
                if (_queue.TryDequeue(out var work))
                {
                    await _semaphore.WaitAsync();

                    try
                    {
                        Interlocked.Increment(ref _runningTasks);

                        // Execute the work on a ThreadPool thread
                        ThreadPool.QueueUserWorkItem(_ =>
                        {
                            try
                            {
                                work.Item1(work.Item2);
                            }
                            finally
                            {
                                Interlocked.Decrement(ref _runningTasks);
                                Task.Delay(10).Wait();
                                _semaphore.Release();
                            }
                        });
                    }
                    catch
                    {
                        _semaphore.Release();
                        throw;
                    }
                }
                else
                {
                    await Task.Delay(1); // Small delay when queue is empty
                }
            }
        }

        public int CurrentRunningTasks => _runningTasks;

        public void Dispose()
        {
            _cancellation.Cancel();
            _semaphore.Dispose();
        }
    }

}
