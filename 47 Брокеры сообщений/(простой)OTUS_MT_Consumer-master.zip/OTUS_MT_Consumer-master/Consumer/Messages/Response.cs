namespace CommonNamespace
{
    public class Response
    {
        public bool IsSuccess { get; set; }
    }
}