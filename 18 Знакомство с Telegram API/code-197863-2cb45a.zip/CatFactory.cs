﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Telegram.Bot.Types;
using Telegram.Bot;

namespace Otus.Telegram
{
    public class CatFactory
    {
        public Task Process(ITelegramBotClient client, Update update, CancellationToken ct)
        {
            var message = update.Message;
            if (message == null)
            {
                return Task.CompletedTask;
            }

            if (message.Text != null)
            {
                switch (message.Text)
                {
                    case "/sendcat":
                        SendRandomCat(client, update, ct).Wait();
                        break;
                    case "/cat":
                        break;

                    default:
                        client.SendTextMessageAsync(
                            chatId: update.Message!.Chat.Id,
                            text: "Я к сожалению не понял сообщения, пришлите пожалуйста еще раз")
                            .Wait();
                        break;
                }
            }

            return Task.CompletedTask;
        }

        async Task SendRandomCat(ITelegramBotClient client, Update update, CancellationToken ct)
        {
            var r = new Random();
            var fileName = r.Next(1, 4);
            var f = System.IO.File.ReadAllBytes($"{fileName}.jpg");

            await client.SendPhotoAsync(


                 chatId: update.Message!.Chat.Id,


                 photo: InputFile.FromStream(
                     fileName: "котик.jpg",
                     stream: new MemoryStream(f)),
                 caption: "Вот вам котик",


                 cancellationToken: ct);
        }

    }
}
