﻿using AsyncAwait;

class Program
{
    static async Task Main(string[] args)
    {

        var customAwaitable = new CustomAwaitable();
        var result = await customAwaitable;
        Console.WriteLine(result);

        var stateMachineExample = new StateMachineExample();
        //await stateMachineExample.PrintAndWaitAsync(TimeSpan.Zero, 0);

        var stateMachineExample2 = new StateMachineExample2();
        //await stateMachineExample2.PrintAndWaitAsync();

        var threadPoolExhaustionIssues = new ThreadPoolExhaustionIssues();
        //threadPoolExhaustionIssues.Example1(); // threadPool
        //await threadPoolExhaustionIssues.Example1Async(); //threadPool2

        //var threadPoolExhaustionIssues2 = new ThreadPoolExhaustionIssuesSecond();
        //await threadPoolExhaustionIssues2.Process();
        //threadPoolExhaustionIssues2.Dispose();

        //await threadPoolExhaustionIssues.Program1();

        //var eventHandlerAsync = new EventHandlerAsync();
        //await eventHandlerAsync.Process();

        //var fetcher = new DataFetcher();
        //// First call will fetch and cache the data
        //Console.WriteLine(await fetcher.GetDataAsync(1)); // Output: Data for ID 1
        //// Second call will return the cached data
        //Console.WriteLine(await fetcher.GetDataAsync(1)); // Output: Data for ID 1 (cached)


        var limitedConcurrencyTaskSchedullerExample = new CustomLimitedConcurrencySchedulerExample();
        await limitedConcurrencyTaskSchedullerExample.Process();


        //var maxConcurrencySynchronizationContextExample = new MaxConcurrencySynchronizationContextExample();
        //await maxConcurrencySynchronizationContextExample.ShowExample();

        //var IAsyncEnumerableExample = new IAsyncEnumerableExample();
        //await IAsyncEnumerableExample.Show();

    }

}
