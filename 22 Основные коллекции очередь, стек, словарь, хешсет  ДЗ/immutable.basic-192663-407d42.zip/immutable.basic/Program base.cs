﻿// using System.Collections.ObjectModel;
// using System.Collections.Specialized;

// internal class Program
// {

//   private static void Main(string[] args)
//   {

//   }

//   static void Log<T>(IEnumerable<T> values)
//   {
//     Console.WriteLine($"[ {String.Join(", ", values)} ]");
//   }

// }