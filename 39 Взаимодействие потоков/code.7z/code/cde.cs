﻿var _now = DateTime.Now;

CountdownEvent countObject = new CountdownEvent(1);
var elementsCount = 10;
int[] input = Enumerable.Range(0, elementsCount).ToArray();
int[] result = new int[elementsCount];

for (int i = 0; i < elementsCount; ++i)
{
    countObject.AddCount();
    int j = i;
    Task.Factory.StartNew(() =>
    {
        Thread.Sleep(20 * j); // Имитируем вычисления
        result[j] = j * 59 - 16 + 42;

        countObject.Signal();

        Log($"[{j}]: {String.Join(" ", result)}");
    });
}

countObject.Signal();
Log("wait");
countObject.Wait();
Log($"{String.Join(" ", result)}");

void Log(string msg)
{
    Console.WriteLine($"{(DateTime.Now - _now).TotalMilliseconds}\t[{Environment.CurrentManagedThreadId}] | {msg}");
}