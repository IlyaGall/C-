﻿internal class Program
{
    static DateTime _now = DateTime.Now;
    static volatile bool stop;

    private static void Main(string[] args)
    {

        var t = Task.Run(DoWork);
        Thread.Sleep(1000);
        stop = true;
        Log("Ждём поток...");
        t.Wait();
        Log("Дождались поток! =)");

        int x = 0;

        // Parallel.For(0, 10_000, i=> x++);
        //Parallel.For(0, 10_000, i=> Interlocked.Increment(ref x));
        ///Log($"{x}");
        ///

    }

    static void DoWork()
    {
        int x = 0;
        while (stop == false)
        {
            x++;
        }
        Log($"{x}");
    }

    static void Log(string msg)
    {
        Console.WriteLine($"{(DateTime.Now - _now).TotalMilliseconds}\t[{Environment.CurrentManagedThreadId}] | {msg}");
    }
}