﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Reflection;

namespace ReflectionConsole
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var myLibraryClass = CreateMyLibraryClass(out Type type);

            InteractionWithField(myLibraryClass, type);

            InteractionWithProperty(myLibraryClass, type);

            InteractionWithMethod(myLibraryClass, type);

            InteractionWithMethodParams(myLibraryClass, type);

            InteractionWithAttributes();
        }

        static object CreateMyLibraryClass(out Type type)
        {
            var assembly = Assembly.LoadFrom(@"D:\Work\Otus\C# Prof\Reflection\MyLibrary\bin\Debug\net8.0\MyLibrary.dll");

            type = assembly.GetType("MyLibrary.MyLibraryClass");

            var myLibraryClass = Activator.CreateInstance(type);

            return myLibraryClass;
        }



        static void InteractionWithField(Object myLibraryClass, Type type)
        {
            var privateField = type.GetFields(BindingFlags.Instance | BindingFlags.NonPublic).First(x => x.Name == "field");

            var fieldValue1 = privateField.GetValue(myLibraryClass);
            Console.WriteLine($"Field value: {fieldValue1??""}");

            Console.Write("Enter new field value: ");
            var valueToSet = Console.ReadLine();

            privateField.SetValue(myLibraryClass, valueToSet);

            var fieldValue2 = privateField.GetValue(myLibraryClass); 

            Console.WriteLine($"Updated field value: {fieldValue2}");
        }

        static void InteractionWithProperty(Object myLibraryClass, Type type)
        {
            var publicProperty = type.GetProperties(BindingFlags.Instance | BindingFlags.Public).First(x => x.Name == "Property");

            Console.WriteLine($"Property was found, " +
                $"get method {(publicProperty.GetMethod != null ? "presented" : "not presented")}" +
                $", set method {(publicProperty.SetMethod != null ? "presented" : "not presented")}");

            var propertyValue1 = publicProperty.GetValue(myLibraryClass);
            Console.WriteLine($"Prop value: {propertyValue1}");

            Console.Write("Enter new prop value: ");
            var valueToSet = int.Parse(Console.ReadLine());

            publicProperty.SetValue(myLibraryClass, valueToSet);

            var propertyValue2 = publicProperty.GetValue(myLibraryClass); 

            Console.WriteLine($"Updated prop value: {propertyValue2}");
        }



        static void InteractionWithMethod(Object myLibraryClass, Type type)
        {
            var methodInfo = type.GetMethods(BindingFlags.Instance | BindingFlags.Public).First(x => x.Name == "Sum");

            Console.WriteLine($"Method was found");
            var parameterValues = new List<object>();

            foreach(var parameter in methodInfo.GetParameters())
            {
                if (parameter.ParameterType != typeof(int))
                    throw new NotImplementedException();

                Console.Write($"Enter parameter {parameter.Name}: ");
                var value = Console.ReadLine();

                var intValue = int.Parse(value);
                parameterValues.Add(intValue);
            }

            var result = methodInfo.Invoke(myLibraryClass, parameterValues.ToArray());
            Console.WriteLine($"Result: {result}");
        }

        static void InteractionWithMethodParams(Object myLibraryClass, Type type)
        {
            var methodInfo = type.GetMethods(BindingFlags.Instance | BindingFlags.Public).First(x => x.Name == "SumParams");

            Console.WriteLine($"Method was found, parameters count: {methodInfo.GetParameters().Length}, parameters names: {string.Join(",", methodInfo.GetParameters().Select(x => x.Name))}");

        }

        private static void InteractionWithAttributes()
        {
            var assembly = Assembly.LoadFrom(@"D:\Work\Otus\C# Prof\Reflection\MyLibrary\bin\Debug\net8.0\MyLibrary.dll");

            var types = assembly.GetTypes();

            foreach (var type in types)
            {
                var tableAttr = type.GetCustomAttribute<TableAttribute>();
                if (tableAttr == null)
                    continue;

                Console.WriteLine($"Found type: {type.Name}, mapped to [{tableAttr.Schema}].[{tableAttr.Name}]");

                foreach (var prop in type.GetProperties())
                {
                    var columnAttr = prop.GetCustomAttribute<ColumnAttribute>();
                    if (columnAttr == null)
                        continue;

                    Console.WriteLine($"Found column: {prop.Name}, mapped to [{columnAttr.Name}], type: {columnAttr.TypeName}");
                }
            }
        }
    }
}
