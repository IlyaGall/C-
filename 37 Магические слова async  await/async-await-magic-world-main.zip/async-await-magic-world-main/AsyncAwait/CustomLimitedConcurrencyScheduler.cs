﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncAwait
{
    public class CustomLimitedConcurrencyScheduler : TaskScheduler
    {
        // Queue to hold tasks
        private readonly ConcurrentQueue<Task> _taskQueue;

        // Current count of running tasks
        private int _currentTaskCount;

        // Maximum allowed concurrent tasks
        private readonly int _maxConcurrentTasks;

        // Lock object for synchronization
        private readonly object _syncRoot = new object();

        public CustomLimitedConcurrencyScheduler(int maxConcurrentTasks)
        {
            if (maxConcurrentTasks < 1)
                throw new ArgumentOutOfRangeException(nameof(maxConcurrentTasks));

            _maxConcurrentTasks = maxConcurrentTasks;
            _taskQueue = new ConcurrentQueue<Task>();
        }

        protected override IEnumerable<Task> GetScheduledTasks()
        {
            return _taskQueue.ToArray();
        }

        protected override void QueueTask(Task task)
        {
            _taskQueue.Enqueue(task);

            // Try to process queued tasks
            TryProcessQueuedTasks();
        }

        protected override bool TryExecuteTaskInline(Task task, bool taskWasPreviouslyQueued)
        {
            // Don't execute tasks inline
            return false;
        }

        private void TryProcessQueuedTasks()
        {
            lock (_syncRoot)
            {
                // Process tasks while we're under our limit and have tasks to process
                while (Interlocked.Read(_currentTaskCount) < _maxConcurrentTasks && _taskQueue.TryDequeue(out Task task))
                {
                    Interlocked.Increment(ref _currentTaskCount);

                    ThreadPool.QueueUserWorkItem(_ =>
                    {
                        try
                        {
                            // Execute the task
                            TryExecuteTask(task);
                        }
                        finally
                        {
                            // Decrease the count and try to process more tasks
                            Interlocked.Decrement(ref _currentTaskCount);
                            TryProcessQueuedTasks();
                        }
                    });
                }
            }
        }
    }
}
