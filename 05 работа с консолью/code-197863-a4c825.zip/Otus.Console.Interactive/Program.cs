﻿
namespace Otus.Console.Interactive
{
    using System;
    using System.Globalization;

    class Program
    {




        static void Main(string[] args)
        {


            // Как работает каждая функиця по отдельности 
            // Можно закомментировать 



            //  WriteDemo.Demo();
            //ReadDemo.Demo();
            //ColorDemo.Demo();
            	ComplexMenuDemo.Demo();

        }
    }
}
