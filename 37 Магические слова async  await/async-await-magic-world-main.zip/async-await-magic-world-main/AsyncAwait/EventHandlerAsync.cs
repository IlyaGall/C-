﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncAwait
{
    internal class EventHandlerAsync
    {
        public event Func<Task> OnEventAsync;

        public async Task Process()
        {
            // Subscribe multiple async event handlers
            OnEventAsync += async () =>
            {
                Console.WriteLine("Handler 1 starting...");
                await Task.Delay(1000); // Simulate async work
                Console.WriteLine("Handler 1 completed.");
            };

            OnEventAsync += async () =>
            {
                Console.WriteLine("Handler 2 starting...");
                await Task.Delay(500); // Simulate async work
                Console.WriteLine("Handler 2 completed.");
            };

            OnEventAsync += async () =>
            {
                Console.WriteLine("Handler 3 starting...");
                await Task.Delay(800); // Simulate async work
                Console.WriteLine("Handler 3 completed.");
            };

            // Raise the event and wait for all handlers to complete
            if (OnEventAsync != null)
            {
                Console.WriteLine("Raising event...");
                await InvokeEventAsync(OnEventAsync);
                Console.WriteLine("All handlers completed.");
            }
            else
            {
                Console.WriteLine("No handlers subscribed to the event.");
            }
        }

        // Helper method to invoke all event handlers asynchronously
        private async Task InvokeEventAsync(Func<Task> eventHandlers)
        {
            var invocationList = eventHandlers.GetInvocationList();
            var tasks = new List<Task>();

            foreach (var handler in invocationList)
            {
                // Invoke each handler and add the resulting task to the list
                tasks.Add(((Func<Task>)handler)());
            }

            // Wait for all handlers to complete
            await Task.WhenAll(tasks);
        }
    }
}
