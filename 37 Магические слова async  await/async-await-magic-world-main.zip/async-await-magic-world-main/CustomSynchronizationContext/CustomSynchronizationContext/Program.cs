﻿using CustomSynchronizationContext;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine($"Current SynchronizationContext : {SynchronizationContext.Current}");

 
        var sc = new QueueSynchronizationContext();

        SynchronizationContext.SetSynchronizationContext(sc);

        // Execute async method.
        // (Usually thread awaited and return from MainAsync...)
        var task = MainAsync(args);

        var a = 1;

        // Start synchronization context infrastracture.
        sc.Run(task);
    }


    // Async method entry point.
    private static async Task MainAsync(string[] args)
    {
        // Start the custom context

        Console.WriteLine($"\nThread ID: {Thread.CurrentThread.ManagedThreadId}");

        await TestConfigureAwait(false);

        Console.WriteLine($"\nThread ID: {Thread.CurrentThread.ManagedThreadId}");


        await TestConfigureAwait(true);

        Console.WriteLine($"\nThread ID: {Thread.CurrentThread.ManagedThreadId}");

        Console.WriteLine($"Current SynchronizationContext : {SynchronizationContext.Current}");



    }

    static async Task TestConfigureAwait(bool captureContext)
    {
        Console.WriteLine($"\nStarting TestConfigureAwait(captureContext: {captureContext}) on Thread ID: {Thread.CurrentThread.ManagedThreadId}");

        await Task.Delay(1000).ConfigureAwait(captureContext);

        Console.WriteLine($"Continuation in TestConfigureAwait(captureContext: {captureContext}) on Thread ID: {Thread.CurrentThread.ManagedThreadId}");
    }
}
