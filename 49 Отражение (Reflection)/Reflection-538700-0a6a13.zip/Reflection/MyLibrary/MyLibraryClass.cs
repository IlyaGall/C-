﻿using System.Linq;

namespace MyLibrary
{
    public class MyLibraryClass
    {
        private string field;
        public int Property { get; set; }
        public int Sum(int a, int b, int c) => a + b + c;

        public int SumParams(params int[] a) => a.Sum();
    }
}
