﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncAwait
{
    public class CustomLimitedConcurrencySchedulerExample
    {
        public async Task Process()
        {
            // Create scheduler that allows 2 concurrent tasks
            var scheduler = new CustomLimitedConcurrencyScheduler(maxConcurrentTasks: 3);

            // Create a list to hold all tasks
            var tasks = new List<Task>();

            // Create 5 tasks that will run on our custom scheduler
            for (int i = 0; i < 12; i++)
            {
                int taskNumber = i;
                var task = new Task(() =>
                {
                    Console.WriteLine($"Starting Task {taskNumber} on thread {Thread.CurrentThread.ManagedThreadId}");
                    Thread.Sleep(1000); // Simulate work
                    Console.WriteLine($"Completed Task {taskNumber}");
                });

                // Start the task on our custom scheduler
                task.Start(scheduler);
                tasks.Add(task);
            }

            // Wait for all tasks to complete
            await Task.WhenAll(tasks);
            Console.WriteLine("All tasks completed!");
        }
       
    }
}
