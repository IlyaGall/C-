﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncAwait
{
    internal class ThreadPoolExhaustionIssuesSecond:IDisposable
    {
        private  readonly HttpClient httpClient = new HttpClient();
        private  int completedTasks = 0;
        private  readonly object lockObject = new object();

         internal async Task Process()
        {
            // Monitor thread pool statistics
            var timer = new Timer(MonitorThreadPool, null, 0, 1000);

            Console.WriteLine("Starting tasks...");
            var stopwatch = Stopwatch.StartNew();

            // Create a large number of tasks that will cause thread pool exhaustion
            var tasks = new List<Task>();
            for (int i = 0; i < 1000; i++)
            {
               // tasks.Add(SimulateBlockingWorkWithAsync());
                tasks.Add(SimulateWorkCorrectlyAsync());
            }

            await Task.WhenAll(tasks);

            stopwatch.Stop();
            Console.WriteLine($"\nAll tasks completed in {stopwatch.ElapsedMilliseconds}ms");
            Console.WriteLine($"Total completed tasks: {completedTasks}");
        }

        private  async Task SimulateBlockingWorkWithAsync()
        {
            try
            {
                // This is the WRONG way - blocking in async code
                await Task.Run(() =>
                {
                    // Simulate CPU-bound work that blocks
                    Thread.Sleep(1000);

                    // Simulate I/O work immediately after
                    var result = httpClient.GetStringAsync("http://example.com").Result; // Blocking call!
                });

                Interlocked.Increment(ref completedTasks);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Task failed: {ex.Message}");
            }
        }

        private  void MonitorThreadPool(object state)
        {
            ThreadPool.GetAvailableThreads(out int workerThreads, out int completionPortThreads);
            ThreadPool.GetMaxThreads(out int maxWorkerThreads, out int maxCompletionPortThreads);

            Console.WriteLine($"\nThread Pool Status:" +
                $"\nAvailable Worker Threads: {workerThreads}/{maxWorkerThreads}" +
                $"\nAvailable IO Threads: {completionPortThreads}/{maxCompletionPortThreads}");
        }

        // Here's the CORRECT way to implement the same operation
        private  async Task SimulateWorkCorrectlyAsync()
        {
            try
            {
                // CPU-bound work should use Task.Run
                await Task.Run(async () =>
                {
                    // Simulate CPU work without blocking
                    await Task.Delay(1000);

                    // Proper async I/O operation
                    var result = await httpClient.GetStringAsync("http://example.com");
                });

                Interlocked.Increment(ref completedTasks);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Task failed: {ex.Message}");
            }
        }

        public void Dispose()
        {
            httpClient?.Dispose();
        }
    }
}
